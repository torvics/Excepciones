import java.util.Scanner;

    public class Excepcion extends Exception {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Introduce una cadena de caracteres: ");
            String inputString = scanner.nextLine();

            System.out.print("Introduce la posición del carácter que deseas obtener: ");
            int num = scanner.nextInt();

            scanner.close();

            try {
                char character = caracterEn(inputString, num);
                int pos = 7;
                char posicion7 = caracterEn(inputString, pos);

                System.out.println("El carácter en la posición " + num + " es: " + character);
                System.out.println("El caráter en al posicion 7 es: " + posicion7);
            } catch (Excepcion e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        public Excepcion(String mensaje) {
            super(mensaje);
        }

        public static char caracterEn(String cadena, int num) throws Excepcion {
            if (num >= 0 && num < cadena.length()) {
                return cadena.charAt(num);
            } else {
                throw new Excepcion("La posición debe estar dentro del rango de la cadena");
            }
        }
    }

