import java.util.Scanner;

public class NumeroNegativoExcepcion extends Exception {
    public NumeroNegativoExcepcion() {
        super("Se ha ingresado un número negativo.");
    }

    public NumeroNegativoExcepcion(String mensaje) {
        super(mensaje);
    }

 public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce un valor numérico: ");
        double numero = scanner.nextDouble();

        scanner.close();

        try {
            if (numero < 0) {
                throw new NumeroNegativoExcepcion();
            } else {
                double raizCuadrada = Math.sqrt(numero);
                System.out.println("La raíz cuadrada es: " + raizCuadrada);
            }
        } catch (NumeroNegativoExcepcion e) {
            System.out.println("Excepción: " + e.getMessage());
        }
    }
}